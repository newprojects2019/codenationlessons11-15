//
//  CoffeesTableViewController.swift
//  coffeeshopmobile
//
//  Created by Code Nation on 04/03/2019.
//  Copyright © 2019 tania. All rights reserved.
//

import Foundation
struct coffee {
    
    //MARK: - Properties
    var name: String;
    var store: String;
    var rating: Int;
}
